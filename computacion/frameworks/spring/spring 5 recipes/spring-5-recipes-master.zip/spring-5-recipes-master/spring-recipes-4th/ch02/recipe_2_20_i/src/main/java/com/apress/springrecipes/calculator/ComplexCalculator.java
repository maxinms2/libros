package com.apress.springrecipes.calculator;

public interface ComplexCalculator {

    public Complex add(Complex a, Complex b);

    public Complex sub(Complex a, Complex b);
}
