package com.apress.springrecipes.calculator;

public interface MinCalculator {

    double min(double a, double b);
}
