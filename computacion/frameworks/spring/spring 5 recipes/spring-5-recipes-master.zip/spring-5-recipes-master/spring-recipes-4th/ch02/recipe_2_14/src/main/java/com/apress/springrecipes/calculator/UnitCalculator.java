package com.apress.springrecipes.calculator;

public interface UnitCalculator {

    double kilogramToPound(double kilogram);

    double kilometerToMile(double kilometer);
}
