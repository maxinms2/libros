package com.apress.springrecipes.calculator;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Created by marten on 24-01-17.
 */
@Configuration
@ComponentScan
public class CalculatorConfiguration {
}
