package com.apress.springrecipes.calculator;

public interface ComplexCalculator {

    Complex add(Complex a, Complex b);

    Complex sub(Complex a, Complex b);
}
