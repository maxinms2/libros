package com.apress.springrecipes.calculator;

public interface Counter {

    void increase();

    int getCount();
}
