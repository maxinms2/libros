package com.apress.springrecipes.sequence;

public interface PrefixGenerator {

    public String getPrefix();
}
