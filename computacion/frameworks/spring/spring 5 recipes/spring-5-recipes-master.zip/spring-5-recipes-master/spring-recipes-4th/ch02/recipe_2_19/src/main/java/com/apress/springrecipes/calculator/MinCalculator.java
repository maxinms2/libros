package com.apress.springrecipes.calculator;

public interface MinCalculator {

    public double min(double a, double b);
}
