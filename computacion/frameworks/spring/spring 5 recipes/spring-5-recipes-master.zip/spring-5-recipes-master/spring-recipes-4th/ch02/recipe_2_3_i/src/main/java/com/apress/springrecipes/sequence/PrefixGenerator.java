package com.apress.springrecipes.sequence;

public interface PrefixGenerator {

    String getPrefix();
}
