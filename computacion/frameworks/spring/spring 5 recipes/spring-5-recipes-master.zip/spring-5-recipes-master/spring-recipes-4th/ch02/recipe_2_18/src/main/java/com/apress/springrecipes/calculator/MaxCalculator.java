package com.apress.springrecipes.calculator;

public interface MaxCalculator {

    double max(double a, double b);
}

