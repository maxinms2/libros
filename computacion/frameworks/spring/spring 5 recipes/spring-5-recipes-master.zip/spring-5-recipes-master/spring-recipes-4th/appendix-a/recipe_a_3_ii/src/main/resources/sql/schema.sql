create table contact (
  id bigint primary key AUTO_INCREMENT,
  name varchar(50) not null,
  email varchar(50) not null
);