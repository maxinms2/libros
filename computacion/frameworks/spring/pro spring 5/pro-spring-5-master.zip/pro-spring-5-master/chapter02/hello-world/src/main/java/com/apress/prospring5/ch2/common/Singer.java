package com.apress.prospring5.ch2.common;

/**
 * Created by iuliana.cosmina on 4/2/17.
 */
public interface Singer {
	void sing();
}
