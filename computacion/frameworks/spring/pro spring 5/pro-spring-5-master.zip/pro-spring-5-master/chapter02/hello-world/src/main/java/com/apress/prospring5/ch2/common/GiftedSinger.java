package com.apress.prospring5.ch2.common;

/**
 * Created by iuliana.cosmina on 4/2/17.
 */
public interface GiftedSinger extends Singer {
	void play(Guitar guitar);
}
