package com.apress.prospring5.ch8;

import org.hibernate.envers.DefaultRevisionEntity;

/**
 * Created by iuliana.cosmina on 5/8/17.
 */
public class CustomDefaultRevisionEntity extends DefaultRevisionEntity {

}
