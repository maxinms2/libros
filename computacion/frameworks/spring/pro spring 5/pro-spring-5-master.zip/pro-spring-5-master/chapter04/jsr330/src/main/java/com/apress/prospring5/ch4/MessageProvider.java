package com.apress.prospring5.ch4;

public interface MessageProvider {
    String getMessage();
}
