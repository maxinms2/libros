package com.apress.prospring5.ch3;

public interface Container {
    Object getDependency(String key);
}
