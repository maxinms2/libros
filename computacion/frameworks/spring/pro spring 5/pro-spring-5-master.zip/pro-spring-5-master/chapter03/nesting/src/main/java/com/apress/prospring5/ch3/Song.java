package com.apress.prospring5.ch3;

public class Song {
    private String title;
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getTitle() {
        return title;
    }
}
