package com.apress.prospring5.ch3;

public interface DemoBean {
    Singer getMySinger();
    void doSomething();
}
