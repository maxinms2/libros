package com.apress.prospring5.ch3.xml;

public class Foo {
    
}
